//
//  InContextSDK.h
//  InContextSDK
//
//  Created by Carlos Viejo on 11/05/2017.
//  Copyright © 2017 eye square. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for InContextSDK.
FOUNDATION_EXPORT double InContextSDKVersionNumber;

//! Project version string for InContextSDK.
FOUNDATION_EXPORT const unsigned char InContextSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <InContextSDK/PublicHeader.h>


